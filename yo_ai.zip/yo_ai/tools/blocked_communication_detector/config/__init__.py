# Makes yo_ai/tools/blocked_communication_detector/config importable as a package
