/**
 * This DataBroker-Monitor Extended Agent Card conveys:
 * - ExtendedCard contains tasks, messages, artifacts, and tools for Registered Agents
 * - Overall details (version, name, description, uses)
 * - Skills: A set of capabilities the agent can perform
 * - Default modalities/content types supported by the agent.
 */

/**
* DataBroker-Monitor Extended Agent Card¶
*/
{
    "name": "DataBroker-Monitor",
    "description": "Monitors registered data brokers to detect possession, sale, or distribution of personal information and identify downstream purchasers.",
    "id": "com.privacyportfolio.databroker-monitor",
    "provider": {
      "organization": "PrivacyPortfolio",
      "url": "https://www.PrivacyPortfolio.com"
    },
    "iconUrl": "https://privacyportfolio.com/agent-directory/databroker-monitor/databroker-monitor-agent-icon.png",
    "protocolVersion": "1.0.0",
    "documentationUrl": "https://privacyportfolio.com/agent-directory/databroker-monitor/auth/DataBroker-Monitor-ExtendedAgentCard.md",
    "supportedInterfaces": [
      {      "url": "https://privacyportfolio.com/agents/databroker_monitor/a2a",
        "protocolBinding": "JSONRPC_HTTP",      "protocolVersion": "1.0"    },
      {      "url": "https://privacyportfolio.com/agents/databroker_monitor/mesh",
        "protocolBinding": "RPC",      "protocolVersion": "1.0"    },
      {      "url": "https://privacyportfolio.com/agents/databroker_monitor/api",
        "protocolBinding": "OPENAI_API",      "protocolVersion": "1.0"    },
      {      "url": "https://privacyportfolio.com/agents/databroker_monitor/app",
        "protocolBinding": "MCP",      "protocolVersion": "1.0"    },
      {      "url": "https://privacyportfolio.com/agents/databroker_monitor/op",
        "protocolBinding": "REST",      "protocolVersion": "1.0"    }
    ], 
    "capabilities": {
        "streaming": true,
        "pushNotifications": true,
        "exposesTasks": true,
        "exposesMessages": true,
        "exposesArtifacts": true,
        "exposesTools": true
    },
    "securitySchemes": {
        "yo-ai": {
            "type": "apiKey",
            "name": "yo-api",
            "in": "header"
        }
    },
    "security": [{ "yo-ai": [] }],
    "defaultInputModes": ["application/json", "text/plain"],
    "defaultOutputModes": ["application/json", "text/plain"],
    "skills": [
        {"name": "Broker-Inventory.Scan"},
        {"name": "Downstream-Vendors.Identify"},
        {"name": "Broker-Evidence.Collect"}
    ],
    "x-ai": {
      "providers": [
        {
          "provider": "google-gemini",
          "model": "gemini-2.0-pro"
        },
        {
          "provider": "anthropic",
          "model": "claude-3-sonnet-20240229"
        },
        {
          "provider": "openai",
          "model": "gpt-4-turbo"
        },
        {
          "provider": "azure-openai",
          "deployment": "gpt-4o"
        }
      ],
      "strategy": "failover",
      "health_ttl_seconds": 300
    },  
    "x-capabilities": [
        {
            "Broker-Inventory.Scan": {
                "artifacts": [
                    {"artifact": {"type": "skill", "name": "Broker-Inventory.Scan"}},
                    {"artifact": {"type": "task", "name": "Broker-Inventory.Scan"}},
                    {"artifact": {"type": "tool", "name": "Broker-Inventory.Scan"}},
                    {"artifact": {"type": "handler", "name": "Broker-Inventory.Scan"}},
                    {"artifact": {"type": "messageType", "name": "Broker-Inventory.Scan.Input"}},
                    {"artifact": {"type": "messageType", "name": "Broker-Inventory.Scan.Output"}}
                ]
            }
        },
        {
            "Downstream-Vendors.Identify": {
                "artifacts": [
                    {"artifact": {"type": "skill", "name": "Downstream-Vendors.Identify"}},
                    {"artifact": {"type": "task", "name": "Downstream-Vendors.Identify"}},
                    {"artifact": {"type": "tool", "name": "Downstream-Vendors.Identify"}},
                    {"artifact": {"type": "handler", "name": "Downstream-Vendors.Identify"}},
                    {"artifact": {"type": "messageType", "name": "Downstream-Vendors.Identify.Input"}},
                    {"artifact": {"type": "messageType", "name": "Downstream-Vendors.Identify.Output"}}
                ]
            }
        },
        {
            "Broker-Evidence.Collect": {
                "artifacts": [
                    {"artifact": {"type": "skill", "name": "Broker-Evidence.Collect"}},
                    {"artifact": {"type": "task", "name": "Broker-Evidence.Collect"}},
                    {"artifact": {"type": "tool", "name": "Broker-Evidence.Collect"}},
                    {"artifact": {"type": "handler", "name": "Broker-Evidence.Collect"}},
                    {"artifact": {"type": "messageType", "name": "Broker-Evidence.Collect.Input"}},
                    {"artifact": {"type": "messageType", "name": "Broker-Evidence.Collect.Output"}}
                ]
            }
        }
    ],
    "x-artifacts": [
      {
        "name": "Broker-Inventory.Scan",
        "version": "1.0.0",
        "artifactType": "skill",
        "description": "Searches registered data broker datasets for matches to minimized PI bundles.",
        "tags": ["broker", "scan", "inventory", "logEvent"],
        "examples": [
          "Search for email in broker dataset",
          "Check if phone number appears in broker feed",
          "Scan for profile matches"
        ]
      },
      {
        "name": "Broker-Inventory.Scan",
        "version": "1.0.0",
        "artifactType": "task",
        "description": "Searches registered data broker datasets for matches to minimized PI bundles.",
        "tags": ["broker", "scan", "inventory", "logEvent"],
        "examples": [
          "Search for email in broker dataset",
          "Check if phone number appears in broker feed",
          "Scan for profile matches"
        ]
      },
      {
        "name": "Broker-Inventory.Scan",
        "version": "1.0.0",
        "artifactType": "tool",
        "description": "Searches registered data broker datasets for matches to minimized PI bundles.",
        "capabilities": ["scan"],
        "path": "/",
        "provider": {
          "name": "PrivacyPortfolio",
          "brand": "Yo-ai",
          "product": "",
          "version": "1.0.0",
          "license": "Yo-ai Internal",
          "url": "https://yo-ai.ai/docs/Broker-Inventory.Scan.html",
          "config": { "backend": "" }
        },
        "inputSchema": {
          "$ref": "https://yo-ai.ai/schemas/broker-inventory.scan.input.schema.json"
        },
        "outputSchema": {
          "$ref": "https://yo-ai.ai/schemas/broker-inventory.scan.output.schema.json"
        },
        "auth": "apiKey"
      },
      {
        "name": "Broker-Inventory.Scan",
        "version": "1.0.0",
        "artifactType": "handler",
        "description": "Interface for integrating with tool executable.",
        "path": "/"
      },
      {
        "name": "Broker-Inventory.Scan.Input",
        "version": "1.0.0",
        "artifactType": "messageType",
        "schema": {
          "$ref": "https://yo-ai.ai/schemas/broker-inventory.scan.input.schema.json"
        },
        "description": "Input schema for the Broker-Inventory.Scan capability."
      },
      {
        "name": "Broker-Inventory.Scan.Output",
        "version": "1.0.0",
        "artifactType": "messageType",
        "schema": {
          "$ref": "https://yo-ai.ai/schemas/broker-inventory.scan.output.schema.json"
        },
        "description": "Output schema for the Broker-Inventory.Scan capability."
      },
      {
        "name": "Downstream-Vendors.Identify",
        "version": "1.0.0",
        "artifactType": "skill",
        "description": "Identifies downstream vendors purchasing or using data from brokers.",
        "tags": ["vendors", "broker", "downstream", "logEvent"],
        "examples": [
          "Identify vendor purchasing my data",
          "Check if broker sold data to advertiser",
          "Map broker → vendor relationships"
        ]
      },
      {
        "name": "Downstream-Vendors.Identify",
        "version": "1.0.0",
        "artifactType": "task",
        "description": "Identifies downstream vendors purchasing or using data from brokers.",
        "tags": ["vendors", "broker", "downstream", "logEvent"],
        "examples": [
          "Identify vendor purchasing my data",
          "Check if broker sold data to advertiser",
          "Map broker → vendor relationships"
        ]
      },
      {
        "name": "Downstream-Vendors.Identify",
        "version": "1.0.0",
        "artifactType": "tool",
        "description": "Identifies downstream vendors purchasing or using data from brokers.",
        "capabilities": ["identify"],
        "path": "/",
        "provider": {
          "name": "PrivacyPortfolio",
          "brand": "Yo-ai",
          "product": "",
          "version": "1.0.0",
          "license": "Yo-ai Internal",
          "url": "https://yo-ai.ai/docs/Downstream-Vendors.Identify.html",
          "config": { "backend": "" }
        },
        "inputSchema": {
          "$ref": "https://yo-ai.ai/schemas/downstream-vendors.identify.input.schema.json"
        },
        "outputSchema": {
          "$ref": "https://yo-ai.ai/schemas/downstream-vendors.identify.output.schema.json"
        },
        "auth": "apiKey"
      },
      {
        "name": "Downstream-Vendors.Identify",
        "version": "1.0.0",
        "artifactType": "handler",
        "description": "Interface for integrating with tool executable.",
        "path": "/"
      },
      {
        "name": "Downstream-Vendors.Identify.Input",
        "version": "1.0.0",
        "artifactType": "messageType",
        "schema": {
          "$ref": "https://yo-ai.ai/schemas/downstream-vendors.identify.input.schema.json"
        },
        "description": "Input schema for the Downstream-Vendors.Identify capability."
      },
      {
        "name": "Downstream-Vendors.Identify.Output",
        "version": "1.0.0",
        "artifactType": "messageType",
        "schema": {
          "$ref": "https://yo-ai.ai/schemas/downstream-vendors.identify.output.schema.json"
        },
        "description": "Output schema for the Downstream-Vendors.Identify capability."
      },
      {
        "name": "Broker-Evidence.Collect",
        "version": "1.0.0",
        "artifactType": "skill",
        "description": "Captures structured evidence of broker possession or sale of personal information.",
        "tags": ["evidence", "broker", "compliance", "logEvent"],
        "examples": [
          "Record broker match",
          "Store dataset reference",
          "Capture sale metadata"
        ]
      },
      {
        "name": "Broker-Evidence.Collect",
        "version": "1.0.0",
        "artifactType": "task",
        "description": "Captures structured evidence of broker possession or sale of personal information.",
        "tags": ["evidence", "broker", "compliance", "logEvent"],
        "examples": [
          "Record broker match",
          "Store dataset reference",
          "Capture sale metadata"
        ]
      },
      {
        "name": "Broker-Evidence.Collect",
        "version": "1.0.0",
        "artifactType": "tool",
        "description": "Captures structured evidence of broker possession or sale of personal information.",
        "capabilities": ["collect"],
        "path": "/",
        "provider": {
          "name": "PrivacyPortfolio",
          "brand": "Yo-ai",
          "product": "",
          "version": "1.0.0",
          "license": "Yo-ai Internal",
          "url": "https://yo-ai.ai/docs/Broker-Evidence.Collect.html",
          "config": { "backend": "" }
        },
        "inputSchema": {
          "$ref": "https://yo-ai.ai/schemas/broker-evidence.collect.input.schema.json"
        },
        "outputSchema": {
          "$ref": "https://yo-ai.ai/schemas/broker-evidence.collect.output.schema.json"
        },
        "auth": "apiKey"
      },
      {
        "name": "Broker-Evidence.Collect",
        "version": "1.0.0",
        "artifactType": "handler",
        "description": "Interface for integrating with tool executable.",
        "path": "/"
      },
      {
        "name": "Broker-Evidence.Collect.Input",
        "version": "1.0.0",
        "artifactType": "messageType",
        "schema": {
          "$ref": "https://yo-ai.ai/schemas/broker-evidence.collect.input.schema.json"
        },
        "description": "Input schema for the Broker-Evidence.Collect capability."
      },
      {
        "name": "Broker-Evidence.Collect.Output",
        "version": "1.0.0",
        "artifactType": "messageType",
        "schema": {
          "$ref": "https://yo-ai.ai/schemas/broker-evidence.collect.output.schema.json"
        },
        "description": "Output schema for the Broker-Evidence.Collect capability."
      }
    ]
}