/**
 * This Door-Keeper AgentCard conveys:
 * - Overall details (version, name, description, uses)
 * - Skills: A set of capabilities the agent can perform
 * - Default modalities/content types supported by the agent.
 * - ExtendedCard contains tasks and messages for Registered Agents
 */

/**
* Door-Keeper AgentCard¶
*/
{
    "name": "Door-Keeper",
    "description": "Profiles guests and decides who to allow in and for what purpose.",
    "url": "https://privacyportfolio.com/agent-registry/door-keeper/agent.json",
    "provider": {
        "organization": "PrivacyPortfolio",
        "url": "https://www.PrivacyPortfolio.com"
        },
    "iconUrl": "https://privacyportfolio.com/agent-registry/door-keeper/door-keeper-agent-icon.png",
    "version": "0.3.0",
    "documentationUrl": "https://privacyportfolio.com/agent-registry/Door-Keeper-AgentCard.md",
    "capabilities": {
        "streaming": true,
        "pushNotifications": true,
        "stateTransitionHistory": true
    },
    "securitySchemes": {
        "yo-ai": {
        "type": "apiKey",
        "name": "yo-api",
        "in": "header"
        }
    },
    "security": [{ "yo-ai": ["apiKey", "yo-api", "header"] }],
    "defaultInputModes": ["application/json", "text/plain"],
    "defaultOutputModes": ["application/json", "text/plain"],
    "skills": [
        {
            "name": "Visitor.Identify",
            "description": "Identify platform users and activity.",
            "tags": ["decision-event", "decision-factor", "decision-outcome"],
            "inputSchema": { "$ref": "https://yo-ai.ai/schemas/visitor.identify.input.schema.json" },
            "outputSchema": { "$ref": "https://yo-ai.ai/schemas/visitor.identify.output.schema.json" }
        },
        {
            "name": "Subscriber.Register",
            "description": "Generates a RegisteredSubscriber card for qualified subscribers.",
            "tags": ["decision-event", "decision-factor", "decision-outcome"],
            "inputSchema": { "$ref": "https://yo-ai.ai/schemas/subscriber.register.input.schema.json" },
            "outputSchema": { "$ref": "https://yo-ai.ai/schemas/subscriber.register.output.schema.json" }
        },
        {
            "name": "Credentials.Generate",
            "description": "Generates credentials for RegisteredAgents and RegisteredSubscribers.",
            "tags": ["RegisteredAgent", "RegisteredSubscriber", "Visitor"],
            "inputSchema": { "$ref": "https://yo-ai.ai/schemas/credentials.generate.input.schema.json" },
            "outputSchema": { "$ref": "https://yo-ai.ai/schemas/credentials.generate.output.schema.json" }
        },
        {
            "name": "Subscriber.Authenticate",
            "description": "Authenticate subscribers and monitor activity.",
            "tags": ["decision-event", "decision-factor", "decision-outcome"],
            "inputSchema": { "$ref": "https://yo-ai.ai/schemas/subscriber.authenticate.input.schema.json" },
            "outputSchema": { "$ref": "https://yo-ai.ai/schemas/subscriber.authenticate.output.schema.json" }
        },
        {
            "name": "Agent.Register",
            "description": "Generates a RegisteredAgent card for qualified agents.",
            "tags": ["registered-agent", "denied-agent", "pending-registration"],
            "inputSchema": { "$ref": "https://yo-ai.ai/schemas/agent.register.input.schema.json" },
            "outputSchema": { "$ref": "https://yo-ai.ai/schemas/agent.register.output.schema.json" }
        },
        {
            "name": "Trust.Assign",
            "description": "Assigns a trust tier to a visitor and emits VisitorTrustTierAssigned.",
            "tags": [""],
            "inputSchema": { "$ref": "https://yo-ai.ai/schemas/trust.assign.input.schema.json" },
            "outputSchema": { "$ref": "https://yo-ai.ai/schemas/trust.assign.output.schema.json" }
        },
        {
            "name": "AccessRights.Manage",
            "description": "Manage access rights for RegisteredAgents and RegisteredSubscribers.",
            "tags": ["RegisteredAgent", "RegisteredSubscriber", "Visitor"],
            "inputSchema": { "$ref": "https://yo-ai.ai/schemas/accessrights.manage.input.schema.json" },
            "outputSchema": { "$ref": "https://yo-ai.ai/schemas/accessrights.manage.output.schema.json" }
        },
        {
            "name": "Agent.Authenticate",
            "description": "Authenticate agents and monitor activity.",
            "tags": ["decision-event", "decision-factor", "decision-outcome"],
            "inputSchema": { "$ref": "https://yo-ai.ai/schemas/agent.authenticate.input.schema.json" },
            "outputSchema": { "$ref": "https://yo-ai.ai/schemas/agent.authenticate.output.schema.json" }
        }
    ],
    "supportsAuthenticatedExtendedCard": true
}